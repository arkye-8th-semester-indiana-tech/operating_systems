;File: prob0528.cpp
;Computer Systems, Fourth Edition
;Problem 5.28
;
#include <iostream>
using namespace std;

char ch;

int main () {
   cin >> ch;
   ch--;
   cout << ch << endl;
   return 0;
}
