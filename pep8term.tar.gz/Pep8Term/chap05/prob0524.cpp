;File: prob0524.cpp
;Computer Systems, Fourth Edition
;Problem 5.24
;
#include <iostream>
using namespace std;

int num1;
int num2;

int main () {
   cin >> num1 >> num2;
   cout << num2 << endl << num1 << endl;
   return 0;
}
