;File: prob0525.cpp
;Computer Systems, Fourth Edition
;Problem 5.25
;
#include <iostream>
using namespace std;

const char chConst = 'a';
char ch1;
char ch2;

int main () {
   cin >> ch1 >> ch2;
   cout << ch1 << chConst << ch2;
   return 0;
}
